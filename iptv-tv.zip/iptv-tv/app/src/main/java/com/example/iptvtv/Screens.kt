package com.example.iptvtv

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

// ---------- HOME ----------

@Composable
fun Home(
    channels: List<Channel>,
    favs: Set<String>,
    loading: Boolean,
    error: String?,
    onPlay: (List<Channel>, Int) -> Unit,
    onFav: (Channel) -> Unit,
    onSettings: () -> Unit,
    onRefresh: () -> Unit
) {
    val rows = remember(channels, favs) {
        val list = ArrayList<Pair<String, List<Channel>>>()
        val f = channels.filter { it.url in favs }
        if (f.isNotEmpty()) list.add("★ Favorites" to f)
        channels.groupBy { it.group }.forEach { (g, l) -> list.add(g to l) }
        list
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 48.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("IPTV", color = Red, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(16.dp))
                Text("${channels.size} channels", color = Color.Gray)
                Spacer(Modifier.weight(1f))
                Button(onClick = onRefresh) { Text("Refresh") }
                Spacer(Modifier.width(12.dp))
                Button(onClick = onSettings) { Text("Settings") }
            }
        }
        if (loading) item { Text("Loading…", Modifier.padding(horizontal = 48.dp), color = Color.Gray) }
        if (error != null) item { Text(error, Modifier.padding(horizontal = 48.dp), color = Color(0xFFFF6B6B)) }

        items(rows) { (title, list) ->
            Column {
                Text(
                    title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 48.dp, bottom = 8.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 48.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(list) { i, ch ->
                        ChannelCard(
                            ch = ch,
                            fav = ch.url in favs,
                            onClick = { onPlay(list, i) },
                            onLong = { onFav(ch) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelCard(ch: Channel, fav: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    var longDone by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, label = "scale")
    val shape = RoundedCornerShape(8.dp)

    Column(
        Modifier
            .width(190.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .onPreviewKeyEvent { e ->
                if (e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter) {
                    when (e.type) {
                        KeyEventType.KeyDown -> {
                            if (e.nativeKeyEvent.isLongPress && !longDone) {
                                longDone = true
                                onLong()
                            }
                            true
                        }
                        KeyEventType.KeyUp -> {
                            if (longDone) longDone = false else onClick()
                            true
                        }
                        else -> true
                    }
                } else false
            }
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onClick() }, onLongPress = { onLong() })
            }
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(107.dp)
                .clip(shape)
                .background(Color(0xFF2A2A2A))
                .then(if (focused) Modifier.border(3.dp, Color.White, shape) else Modifier),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = ch.logo,
                contentDescription = ch.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(12.dp)
            )
            if (fav) {
                Text("★", color = Color(0xFFFFC107), modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
        Text(
            ch.name,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 14.sp,
            color = if (focused) Color.White else Color.Gray,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

// ---------- SETTINGS ----------

@Composable
fun SettingsScreen(current: String, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(current) }
    Column(
        Modifier.fillMaxSize().padding(64.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Playlist", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Red)
        Text("Enter the M3U playlist URL from your licensed provider.", color = Color.Gray)
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("M3U URL") }
        )
        Button(onClick = { onSave(text.trim()) }, enabled = text.isNotBlank()) {
            Text("Save & Load")
        }
    }
}

// ---------- PLAYER ----------

@Composable
fun PlayerScreen(
    ch: Channel,
    isFav: Boolean,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onFav: () -> Unit
) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build() }
    var error by remember { mutableStateOf<String?>(null) }
    var buffering by remember { mutableStateOf(true) }
    var showInfo by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    val focus = remember { FocusRequester() }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                error = "Can't play this channel (${e.errorCodeName}). Press OK to retry."
            }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) error = null
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    LaunchedEffect(ch.url) {
        error = null
        exo.setMediaItem(MediaItem.fromUri(ch.url))
        exo.prepare()
        exo.playWhenReady = true
    }
    LaunchedEffect(ch.url, tick) {
        showInfo = true
        delay(4000)
        showInfo = false
    }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                when (e.key) {
                    Key.DirectionUp, Key.ChannelUp, Key.PageUp -> { onNext(); true }
                    Key.DirectionDown, Key.ChannelDown, Key.PageDown -> { onPrev(); true }
                    Key.DirectionCenter, Key.Enter -> {
                        if (e.nativeKeyEvent.isLongPress) {
                            onFav()
                        } else if (e.nativeKeyEvent.repeatCount == 0) {
                            if (error != null) {
                                error = null
                                exo.prepare()
                            }
                            tick++
                        }
                        true
                    }
                    else -> false
                }
            }
            .focusRequester(focus)
            .focusable()
    ) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    keepScreenOn = true
                    player = exo
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (buffering && error == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Red)
        }
        val err = error
        if (err != null) {
            Text(err, Modifier.align(Alignment.Center).padding(32.dp), color = Color.White, fontSize = 20.sp)
        }

        AnimatedVisibility(
            visible = showInfo,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomStart)
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                    .padding(48.dp)
            ) {
                Text(
                    (if (isFav) "★ " else "") + ch.name,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(ch.group, color = Color.LightGray)
                Text("▲ ▼ change channel   •   hold OK = favorite   •   Back = list", color = Color.Gray, fontSize = 14.sp)
            }
        }
    }
}
