package com.example.iptvtv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Red = Color(0xFFE50914)
val Bg = Color(0xFF141414)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    onPrimary = Color.White,
                    background = Bg,
                    onBackground = Color.White,
                    surface = Color(0xFF222222),
                    onSurface = Color.White
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App()
                }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var url by remember { mutableStateOf(store.url) }
    var reload by remember { mutableIntStateOf(0) }
    var channels by remember { mutableStateOf(emptyList<Channel>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var favs by remember { mutableStateOf(store.favs) }
    var queue by remember { mutableStateOf(emptyList<Channel>()) }
    var index by remember { mutableIntStateOf(-1) }
    var settings by remember { mutableStateOf(store.url.isBlank()) }

    LaunchedEffect(url, reload) {
        if (url.isBlank()) return@LaunchedEffect
        loading = true
        error = null
        try {
            val list = withContext(Dispatchers.IO) { M3u.load(ctx, url) }
            if (list.isEmpty()) error = "No channels found in this playlist."
            channels = list
        } catch (e: Exception) {
            error = e.message ?: "Failed to load playlist."
        }
        loading = false
    }

    val toggleFav: (Channel) -> Unit = { ch ->
        favs = if (ch.url in favs) favs - ch.url else favs + ch.url
        store.favs = favs
    }

    BackHandler(enabled = index >= 0 || (settings && url.isNotBlank())) {
        if (index >= 0) index = -1 else settings = false
    }

    when {
        index >= 0 && index < queue.size -> PlayerScreen(
            ch = queue[index],
            isFav = queue[index].url in favs,
            onNext = { index = (index + 1) % queue.size },
            onPrev = { index = (index - 1 + queue.size) % queue.size },
            onFav = { toggleFav(queue[index]) }
        )
        settings -> SettingsScreen(url) { newUrl ->
            store.url = newUrl
            url = newUrl
            reload++
            settings = false
        }
        else -> Home(
            channels = channels,
            favs = favs,
            loading = loading,
            error = error,
            onPlay = { list, i -> queue = list; index = i },
            onFav = toggleFav,
            onSettings = { settings = true },
            onRefresh = { reload++ }
        )
    }
}
