package com.example.iptvtv

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Channel(
    val name: String,
    val url: String,
    val logo: String?,
    val group: String
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("iptv", Context.MODE_PRIVATE)

    var url: String
        get() = p.getString("url", "") ?: ""
        set(v) { p.edit().putString("url", v).apply() }

    var favs: Set<String>
        get() = (p.getStringSet("favs", emptySet()) ?: emptySet()).toSet()
        set(v) { p.edit().putStringSet("favs", v).apply() }
}

object M3u {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var logo: String? = null
        var group = "Other"
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    val attrs = attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                    group = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "Other"
                    name = line.substringAfterLast(',').trim().ifBlank { attrs["tvg-name"] ?: "Channel" }
                }
                line.startsWith("#EXTGRP:") -> group = line.removePrefix("#EXTGRP:").trim().ifBlank { "Other" }
                line.isEmpty() || line.startsWith("#") -> {}
                else -> {
                    val n = name
                    if (n != null) {
                        out.add(Channel(n, line, logo, group))
                        name = null
                        logo = null
                        group = "Other"
                    }
                }
            }
        }
        return out
    }

    fun load(ctx: Context, url: String): List<Channel> {
        val cache = File(ctx.cacheDir, "playlist.m3u")
        val text = try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            cache.writeText(body)
            body
        } catch (e: Exception) {
            if (cache.exists()) cache.readText() else throw e
        }
        return parse(text)
    }
}
